<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nom = trim(htmlspecialchars($_POST['nom'] ?? ''));
    $date_naissance = trim(htmlspecialchars($_POST['date_naissance'] ?? ''));
    $numero_telephone = trim(htmlspecialchars($_POST['numero_telephone'] ?? ''));

   
    if (empty($nom) || empty($date_naissance) || empty($numero_telephone)) {
        die("Tous les champs sont obligatoires !");
    }
    if (!ctype_digit($numero_telephone) || strlen($numero_telephone) != 10) {
        die("Le numéro de téléphone doit contenir exactement 10 chiffres.");
    }

    try {
       
        $conn = new PDO("mysql:host=localhost;dbname=testdb", "root", "");
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

       
        $stmt = $conn->prepare("INSERT INTO user (nom, date_naissance, numero_telephone) VALUES (:nom, :date_naissance, :numero_telephone)");
        $stmt->bindParam(':nom', $nom, PDO::PARAM_STR);
        $stmt->bindParam(':date_naissance', $date_naissance, PDO::PARAM_STR);
        $stmt->bindParam(':numero_telephone', $numero_telephone, PDO::PARAM_STR);

     
        $stmt->execute();
        echo "Utilisateur ajouté avec succès !";
    } catch (PDOException $e) {
        die("Erreur lors de l'ajout de l'utilisateur : " . $e->getMessage());
    }
}
?>
