<?php

function sauvegarderUtilisateur($db, $nom, $prenom, $id = null) {
    if ($id) {
       
        $requete = "UPDATE users SET nom = ?, prenom = ? WHERE id = ?";
        $stmt = $db->prepare($requete);
        $stmt->execute([$nom, $prenom, $id]);
    } else {
        
        $requete = "INSERT INTO users (nom, prenom) VALUES (?, ?)";
        $stmt = $db->prepare($requete);
        $stmt->execute([$nom, $prenom]);
    }
}


function recupererUtilisateurParId($db, $id) {
    $requete = "SELECT * FROM users WHERE id = ?";
    $stmt = $db->prepare($requete);
    $stmt->execute([$id]);
    return $stmt->fetch();
}


function recupererTousLesUtilisateurs($db) {
    $requete = "SELECT * FROM users";
    $stmt = $db->prepare($requete);
    $stmt->execute();
    return $stmt->fetchAll();
}
?>
