<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=app_exemple", "root", "root"); // Modifiez "root" et "root" si nécessaire
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}
?>
