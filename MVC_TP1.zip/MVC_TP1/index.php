<?php
require_once 'modele/connexion.php';
require_once 'modele/fonctions.php';


$nom = "";
$prenom = "";
$id = "";


if (isset($_GET["action"])) {
    if ($_GET["action"] == "save") {
        
        if (isset($_GET["id"]) && $_GET["id"] != "") {
            
            modifierUtilisateur($_GET["id"], $_GET["nom"], $_GET["prenom"]);
        } else {
            
            ajouterUtilisateur($_GET["nom"], $_GET["prenom"]);
        }
    }
}


if (isset($_GET["action"]) && ($_GET["action"] == "modifier" || $_GET["action"] == "ajouter")) {
    
    if ($_GET["action"] == "modifier" && isset($_GET["id"])) {
        $user = recupererUtilisateur($_GET["id"]);
        $nom = $user["nom"];
        $prenom = $user["prenom"];
        $id = $user["id"];
    }


    require_once 'views/edit.php';
} else {
    
    $utilisateurs = recupererTousLesUtilisateurs();
    require_once 'views/list.php';
}
?>
