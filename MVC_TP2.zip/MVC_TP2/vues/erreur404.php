<?php 
/**
* Vue : erreur 404
*/
?>

<p>Page demandée inexistante</p>