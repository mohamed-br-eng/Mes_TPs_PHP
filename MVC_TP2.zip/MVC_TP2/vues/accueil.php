<?php 
/**
* Vue : accueil
*/
?>

<p>S'inscrire sur le site : <a href="index.php?cible=utilisateurs&fonction=inscription">Lien</a></p>
<p>Liste des utilisateurs : <a href="index.php?cible=utilisateurs&fonction=liste">lien</a></p>
<p>Liste des Capteurs : <a href="index.php?cible=capteurs">lien</a></p>
