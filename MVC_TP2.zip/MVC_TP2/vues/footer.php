<?php 
/**
* Vue : pied de page
*/
?>

<footer>
    
</footer>
</body>
</html>