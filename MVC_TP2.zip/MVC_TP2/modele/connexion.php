<?php

try{
    // Connexion à la base de données avec XAMPP (port 3306 par défaut)
    $bdd = new PDO('mysql:host=localhost;dbname=mvc;charset=utf8', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
